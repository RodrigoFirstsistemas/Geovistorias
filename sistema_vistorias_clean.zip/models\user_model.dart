import 'package:json_annotation/json_annotation.dart';

part 'user_model.g.dart';

enum UserRole {
  @JsonValue('admin')
  admin,
  @JsonValue('manager')
  manager,
  @JsonValue('inspector')
  inspector,
  @JsonValue('viewer')
  viewer,
  @JsonValue('cashier')
  cashier
}

@JsonSerializable()
class UserModel {
  final String id;
  final String name;
  final String email;
  final String? avatarUrl;
  final List<UserRole> roles;
  final String? organizationId;
  final bool isActive;
  final DateTime createdAt;
  final DateTime? lastLoginAt;

  UserModel({
    required this.id,
    required this.name,
    required this.email,
    this.avatarUrl,
    required this.roles,
    this.organizationId,
    this.isActive = true,
    DateTime? createdAt,
    this.lastLoginAt,
  }) : createdAt = createdAt ?? DateTime.now();

  factory UserModel.fromJson(Map<String, dynamic> json) => 
      _$UserModelFromJson(json);
  
  Map<String, dynamic> toJson() => _$UserModelToJson(this);

  bool hasRole(UserRole role) => roles.contains(role);
  bool hasAnyRole(List<UserRole> roleList) => 
      roles.any((role) => roleList.contains(role));
}
