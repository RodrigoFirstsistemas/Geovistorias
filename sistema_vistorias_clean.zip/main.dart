import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core/app_routes.dart';
import 'services/auth_service.dart';
import 'services/document_template_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Inicializar Supabase
  await Supabase.initialize(
    url: 'https://fzvcqzefwlwpcynqecqk.supabase.co',
    anonKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZ6dmNxemVmd2x3cGN5bnFlY3FrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzM0NTIxMjEsImV4cCI6MjA0OTAyODEyMX0.wHvJCYPE6o1w00FSBKGizpSAT1bW38LSNjcdcD9QCBc',
  );

  // Inicializar SharedPreferences
  final prefs = await SharedPreferences.getInstance();

  // Inicializar AuthService
  await Get.putAsync<AuthService>(() => AuthService(prefs).init());

  // Inicializar DocumentTemplateService
  Get.put(DocumentTemplateService());

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'GeoVistoria',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/login',
      getPages: AppRoutes.routes,
      debugShowCheckedModeBanner: false,
    );
  }
}
