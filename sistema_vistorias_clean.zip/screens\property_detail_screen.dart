import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/property_controller.dart';

class PropertyDetailScreen extends StatelessWidget {
  final String propertyId = Get.parameters['id'] ?? '';
  final PropertyController _propertyController = Get.find<PropertyController>();

  PropertyDetailScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Property Details'),
      ),
      body: Obx(
        () {
          final property = _propertyController.selectedProperty.value;
          if (property == null) {
            return Center(child: CircularProgressIndicator());
          }
          return Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Address',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                Text(property.address),
                SizedBox(height: 16.0),
                Text(
                  'Type',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                Text(property.type),
                // Add more property details here
              ],
            ),
          );
        },
      ),
    );
  }
}
