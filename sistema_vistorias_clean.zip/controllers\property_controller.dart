import 'package:get/get.dart';
import '../models/property_model.dart';
import '../services/property_service.dart';

class PropertyController extends GetxController {
  final PropertyService _propertyService;
  final RxList<PropertyModel> properties = <PropertyModel>[].obs;
  final Rx<PropertyModel?> selectedProperty = Rx<PropertyModel?>(null);
  final RxBool isLoading = false.obs;
  final RxString error = ''.obs;

  PropertyController(this._propertyService);

  @override
  void onInit() {
    super.onInit();
    loadProperties();
  }

  Future<void> loadProperties() async {
    try {
      isLoading.value = true;
      error.value = '';
      final loadedProperties = await _propertyService.getProperties();
      properties.assignAll(loadedProperties);
    } catch (e) {
      error.value = 'Failed to load properties: ${e.toString()}';
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> loadProperty(String id) async {
    try {
      isLoading.value = true;
      error.value = '';
      final property = await _propertyService.getProperty(id);
      selectedProperty.value = property;
    } catch (e) {
      error.value = 'Failed to load property: ${e.toString()}';
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> createProperty(PropertyModel property) async {
    try {
      isLoading.value = true;
      error.value = '';
      final createdProperty = await _propertyService.createProperty(property);
      properties.add(createdProperty);
    } catch (e) {
      error.value = 'Failed to create property: ${e.toString()}';
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> updateProperty(PropertyModel property) async {
    try {
      isLoading.value = true;
      error.value = '';
      final updatedProperty = await _propertyService.updateProperty(property);
      final index = properties.indexWhere((p) => p.id == property.id);
      if (index != -1) {
        properties[index] = updatedProperty;
      }
      if (selectedProperty.value?.id == property.id) {
        selectedProperty.value = updatedProperty;
      }
    } catch (e) {
      error.value = 'Failed to update property: ${e.toString()}';
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> deleteProperty(String id) async {
    try {
      isLoading.value = true;
      error.value = '';
      await _propertyService.deleteProperty(id);
      properties.removeWhere((property) => property.id == id);
      if (selectedProperty.value?.id == id) {
        selectedProperty.value = null;
      }
    } catch (e) {
      error.value = 'Failed to delete property: ${e.toString()}';
    } finally {
      isLoading.value = false;
    }
  }
}
