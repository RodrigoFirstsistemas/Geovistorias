import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../services/auth_service.dart';
import '../models/user_model.dart';

class AuthMiddleware extends GetMiddleware {
  final List<UserRole>? requiredRoles;

  AuthMiddleware({this.requiredRoles});

  @override
  RouteSettings? redirect(String? route) {
    if (!AuthService.to.isAuthenticated) {
      return RouteSettings(name: '/login');
    }

    if (requiredRoles != null && !AuthService.to.hasAnyRole(requiredRoles!)) {
      // Redirecionar para página de acesso negado
      return RouteSettings(name: '/access-denied');
    }

    return null;
  }
}
