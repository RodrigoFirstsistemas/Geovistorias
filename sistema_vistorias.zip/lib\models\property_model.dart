import 'package:json_annotation/json_annotation.dart';

part 'property_model.g.dart';

@JsonSerializable()
class PropertyModel {
  final String? id;
  final String address;
  final String type;
  final String organizationId;
  final Map<String, dynamic> details;
  final DateTime createdAt;
  final DateTime updatedAt;

  PropertyModel({
    this.id,
    required this.address,
    required this.type,
    required this.organizationId,
    Map<String, dynamic>? details,
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : details = details ?? {},
        createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  factory PropertyModel.fromJson(Map<String, dynamic> json) =>
      _$PropertyModelFromJson(json);

  Map<String, dynamic> toJson() => _$PropertyModelToJson(this);

  PropertyModel copyWith({
    String? id,
    String? address,
    String? type,
    String? organizationId,
    Map<String, dynamic>? details,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return PropertyModel(
      id: id ?? this.id,
      address: address ?? this.address,
      type: type ?? this.type,
      organizationId: organizationId ?? this.organizationId,
      details: details ?? Map.from(this.details),
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
